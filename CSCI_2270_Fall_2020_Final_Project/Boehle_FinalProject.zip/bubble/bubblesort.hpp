class BubbleSort
{
public:
    void insert(int *tempArray, int sizeTemp, int *data);
    void print(int array[], int size);
    void sort(int *array, int size);
};